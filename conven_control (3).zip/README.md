# null space posture optimization for redundant manipulator

Null space control for high stiffness posture optimization

## Conventional control

Using Null space projection method for redundant manipulator
to have high stiffness posture.

## Installation

```bash
# recommended
virtualenv venv
source venv/bin/activate
## you can just follow below
pip install -r requirements.txt
pip install -e .
```
