import sympy as sym
sym.init_printing()
a, b, c = sym.symbols('a b c')
# a = sym.Matrix([[a*b, b*c*a*a],
#             [a*b*10*c*0.1, b*b*b*a*c*3.5]])
m1 = sym.Matrix([sym.sin(a)*sym.cos(b)])
m2 = sym.Matrix([sym.tan(c)*sym.sin(c)])

print("  :", m1@m2.T)
print("  :", m1*m2)
sym.init_printing()
# print(a_inv)
